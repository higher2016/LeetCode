package DataStructures;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Map;
import java.util.Set;

public class HashMap<K, V> extends AbstractMap<K, V> implements Map<K, V>, Cloneable, Serializable {

	/**
	 * 默认初始容量是16,容量是哈希表中桶(Entry数组)的数量，初始容量只是哈希表在创建时的容量。
	 */
	static final int DEFAULT_INITIAL_CAPACITY = 1 << 4;

	static final int MAXIMUM_CAPACITY = 1 << 30;

	/**
	 * 默认的加载因子大小(默认值是0.75)<br/>
	 * 加载因子是哈希表在其容量自动增加之前可以达到多满的一种尺度. 当哈希表中的条目数超出了加载因子与当前容量的乘积时，通过调用 rehash
	 * 方法将容量翻倍。
	 */
	static final float DEFAULT_LOAD_FACTOR = 0.75f;

	static final Entry<?, ?>[] EMPTY_TABLE = {};

	/**
	 * Entry数组，哈希表，长度必须为2的幂,这个东西就是存放HashMap所有键值对的数组
	 */
	transient Entry<K, V>[] table = (Entry<K, V>[]) EMPTY_TABLE;

	/**
	 * 已存元素的个数
	 */
	transient int size;

	/**
	 * 下次扩容的临界值（阈值），size>=threshold就会扩容(capacity * load factor).
	 */
	int threshold;

	/**
	 * HashMap对象的实际加载因子大小
	 */
	final float loadFactor;

	/**
	 * 该HashMap结构被修改过的次数（包括扩容修改其映射数或内部结构）
	 */
	transient int modCount;

	/**
	 * 默认的 threshold
	 */
	static final int ALTERNATIVE_HASHING_THRESHOLD_DEFAULT = Integer.MAX_VALUE;

	private static class Holder {
		static final int ALTERNATIVE_HASHING_THRESHOLD;
		static {
			// 读取 Sun定义的threshold的值
			String altThreshold = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("jdk.map.althashing.threshold"));
			int threshold;
			try {
				threshold = (null != altThreshold) ? Integer.parseInt(altThreshold) : ALTERNATIVE_HASHING_THRESHOLD_DEFAULT;

				// disable alternative hashing if -1
				if (threshold == -1) {
					threshold = Integer.MAX_VALUE;
				}

				if (threshold < 0) {
					throw new IllegalArgumentException("value must be positive integer.");
				}
			} catch (IllegalArgumentException failed) {
				throw new Error("Illegal value for 'jdk.map.althashing.threshold'", failed);
			}
			ALTERNATIVE_HASHING_THRESHOLD = threshold;// 虚拟机各自实现中，也会有对应的
														// threshold 设置
		}
	}

	transient int hashSeed = 0;

	/**
	 * 在HashMap所有构造函数都会调用该构造函数（HashMap的母构造函数）
	 * 
	 * @param initialCapacity
	 * @param loadFactor
	 */
	public HashMap(int initialCapacity, float loadFactor) {
		if (initialCapacity < 0)
			throw new IllegalArgumentException("Illegal initial capacity: " + initialCapacity);

		if (initialCapacity > MAXIMUM_CAPACITY)
			initialCapacity = MAXIMUM_CAPACITY;

		if (loadFactor <= 0 || Float.isNaN(loadFactor))
			throw new IllegalArgumentException("Illegal load factor: " + loadFactor);

		this.loadFactor = loadFactor;
		threshold = initialCapacity;
		init();// 因为所有的构造函数都会调用该构造函数，所以直接在这里进行相关初始化
	}

	public HashMap(int initialCapacity) {
		this(initialCapacity, DEFAULT_LOAD_FACTOR);
	}

	public HashMap() {
		this(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR);
	}
	
	public HashMap(Map<? extends K,? extends V> m){
		this(Math)
	}

	private void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<java.util.Map.Entry<K, V>> entrySet() {
		return null;
	}

}
